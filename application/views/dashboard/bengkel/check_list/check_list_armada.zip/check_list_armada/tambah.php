<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-bottom-primary">
            <div class="card-header bg-white py-3">
                <div class="row">
                    <div class="col">
                        <h4 class="h5 align-middle m-0 font-weight-bold text-primary">
                            Form Tambah Check List Armada
                        </h4>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <?= form_open_multipart('', [], ['user_id' => $this->session->userdata('login_session')['user']]); ?>
                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="tgl_laporan">Tanggal Laporan</label>
                    <div class="col-md-9">
                        <?php
                            // Mendapatkan tanggal dalam format "tanggal bulan tahun" (d F Y)
                            $tgl_value = set_value('tgl_laporan', date('Y-m-d'));
                            $tgl_display = date('d F Y', strtotime($tgl_value));
                        ?>
                        <input value="<?= $tgl_value; ?>" name="tgl_laporan" type="date" class="form-control">
                        <?= form_error('tgl_laporan', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="armada_id">Armada</label>
                    <div class="col-md-9">
                        <div class="input-group">

                            <select name="armada_id" id="armada_id" class="custom-select">
                                <option value="" selected disabled>Pilih Armada</option>
                                <?php foreach ($armada as $ar) : ?>
                                <option
                                    <?= set_select('armada_id', $ar['id_armada'], isset($_POST['armada_id']) && $_POST['armada_id'] == $ar['id_armada']) ?>
                                    value="<?= $ar['id_armada'] ?>">
                                    <?= $ar['nama_armada'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>

                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('armada/tambah'); ?>"><i
                                        class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('armada_id', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="montir_id">PIC Montir 1</label>
                    <div class="col-md-9">
                        <div class="input-group">

                            <select name="montir_1" id="montir_id" class="custom-select">
                                <option selected disabled>Pilih Montir</option>
                                <?php foreach ($montir as $ar) : ?>
                                <option
                                    <?= set_select('montir_id', $ar['id_montir'], isset($_POST['montir_id']) && $_POST['montir_id'] == $ar ['id_montir']) ?>
                                    value="<?= $ar['nama_montir'] ?>">
                                    <?= $ar['nama_montir'] ?>
                                </option>
                                <?php endforeach; ?>
                            </select>

                            <div class="input-group-append">
                                <a class="btn btn-primary" href="<?= base_url('montir/tambah'); ?>"><i
                                        class="fa fa-plus"></i></a>
                            </div>
                        </div>
                        <?= form_error('montir_1', '<small class="text-danger">', '</small>'); ?>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="montir_2">PIC Montir 2</label>
                    <div class="col-md-9">
                        <div class="input-group">

                            <select name="montir_2" id="montir_2" class="custom-select">
                                <option selected disabled>Pilih Montir</option>
                                <?php foreach ($montir as $ar) : ?>
                                <option value="<?= $ar['nama_montir'] ?>">
                                    <?= $ar['nama_montir'] ?></option>
                                <?php endforeach; ?>
                            </select>

                        </div>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="image">Upload Foto</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <input name="image" id="image" type="file" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="row form-group">
                    <label class="col-md-3 text-md-right" for="keterangan">Keterangan</label>
                    <div class="col-md-9">
                        <div class="input-group">
                            <input value="<?= set_value('keterangan'); ?>" placeholder="Keterangan" name="keterangan"
                                id="keterangan" type="text" class="form-control">
                        </div>
                    </div>
                </div>

                <div class="row form-group">
                    <div class="col-md-9 offset-md-3">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>

<script>
<?php if ($this->session->flashdata('flash')) { ?>
var isi = <?php echo json_encode($this->session->flashdata('flash')) ?>;
Swal.fire({
    title: "Gagal!",
    text: "<?= $this->session->flashdata('flash') ?>",
    icon: "error",
    button: false,
    timer: 5000,
});
<?php unset($_SESSION['flash']);
    } ?>
</script>