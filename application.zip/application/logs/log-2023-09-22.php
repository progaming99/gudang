<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-09-22 05:16:33 --> Severity: error --> Exception: Unknown column 'barang_keluar.user_id' in 'on clause' C:\xampp\htdocs\sts_gudang\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2023-09-22 05:16:41 --> Severity: error --> Exception: Unknown column 'barang_keluar.user_id' in 'on clause' C:\xampp\htdocs\sts_gudang\system\database\drivers\mysqli\mysqli_driver.php 307
